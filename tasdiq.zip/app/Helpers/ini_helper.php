<?php

function is_selected($a, $b)
{
    if ($a == $b) {
        echo "selected";
    }
}

function genNilai($v): int
{
    return ($v['nilai_un'] + $v['nilai_raport'] + $v['nilai_ps'] + $v['nilai_pa'] + $v['nilai_wawancara']) / 5;
}

function genId($v)
{
    echo $v['tahun'] . str_pad($v['id'], 4, "0", STR_PAD_LEFT);
}

function genId1($v)
{
    print_r($v);
    die();
    // echo $v['tahun'] . "_" . ($v['jurusan'] == 'IPA' ? 'A' : 'B') . str_pad($v['id'], 4, "0", STR_PAD_LEFT);
}
